<?php
declare(strict_types=1);
$root = dirname(__DIR__, 2);
$checks = [
    'theme/header.html', 'theme/home.html', 'theme/footer.html', 'theme/css.css', 'theme/script.js',
    'theme/pages/konversi-usd.html', 'theme/pages/bantuan.html', 'theme/pages/syarat.html',
    'theme/pages/privasi.html', 'theme/pages/refund.html', 'theme/pages/topup-info.html',
    'backend/public/index.php', 'backend/app/TopupCallback.php', 'backend/database/migrations/001_initial.sql',
];
$failed = [];
foreach ($checks as $file) {
    if (!is_file($root . '/' . $file) || filesize($root . '/' . $file) === 0) $failed[] = $file;
}
$css = file_get_contents($root . '/theme/css.css');
$js = file_get_contents($root . '/theme/script.js');
$sql = file_get_contents($root . '/backend/database/migrations/001_initial.sql');
if (strpos($css, '@media(max-width:760px)') === false) $failed[] = 'responsive CSS breakpoint';
if (strpos($js, 'CALISTA_CONFIG') === false || strpos($js, 'secret_callback') !== false) $failed[] = 'browser configuration/security check';
if (strpos($sql, 'uq_topup_token') === false || strpos($sql, 'uq_provider_event') === false) $failed[] = 'database idempotency constraints';
if ($failed) {
    fwrite(STDERR, "FAIL\n - " . implode("\n - ", $failed) . "\n");
    exit(1);
}
echo 'PASS: ' . count($checks) . " required files and static checks\n";
