# CALISTA — Test plan penerimaan

## Status implementasi
- Tema storefront dan halaman informasi: tersedia sebagai source code.
- Navigasi akun, kategori, pencarian, keranjang, dan TopUp native: tautan menuju alur BukaOlshop; perlu diverifikasi pada toko/build pemilik.
- Kalkulator USD: berjalan di browser, rate diisi manual, estimasi saja.
- WhatsApp: tersembunyi sampai nomor admin valid dimasukkan pada konfigurasi non-rahasia.
- Callback Override TopUp: memvalidasi secret dan menyimpan permintaan/pembatalan; tidak membuat invoice dan tidak mengkredit saldo.
- Payment gateway, API katalog, API konfirmasi saldo, dan dashboard admin: belum aktif.

## Otomatis / lokal
1. `php backend/tests/smoke.php` — file wajib, breakpoint mobile, tidak ada secret callback di JS, unique key database.
2. `php -l backend/public/index.php`
3. `php -l backend/app/bootstrap.php`
4. `php -l backend/app/TopupCallback.php`
5. `GET /health` harus menjawab `status=ok` dan `mode=integration_not_configured`.
6. `POST /api/usd-estimate` dengan JSON valid menghasilkan hitungan estimasi, bukan perubahan saldo.
7. USD <= 0, rate <= 0, fee < 0, JSON rusak, dan request terlalu besar harus ditolak.

## Uji integrasi saat kredensial tersedia
1. Produk kosong / kategori tanpa produk.
2. Produk nonaktif / tidak tersedia.
3. Harga berubah saat checkout; harga final dari native checkout.
4. Pengguna belum login; login tetap melalui BukaOlshop.
5. Saldo tidak cukup; hasil dari native checkout.
6. Callback dengan secret salah → 401 dan tidak menulis transaksi.
7. Callback field hilang / jumlah negatif / total tidak cocok → 422.
8. Callback token sama dengan data sama → idempotent 202.
9. Callback token sama dengan data berbeda → 409.
10. Callback `topup_dibatalkan` → hanya menandai permintaan belum dibayar sebagai cancelled.
11. Pembayaran gagal, expired, terlambat, nominal berbeda, signature salah, webhook duplikat.
12. API BukaOlshop timeout, token_topup tidak valid, dan retry konfirmasi.
13. Dua callback bersamaan; unique constraint token mencegah duplikasi.
14. Tidak ada secret di HTML/JS, response browser, atau log.
15. Uji viewport 360px, 390px, tablet, desktop, keyboard dan screen reader.
16. Nomor WhatsApp valid membuka wa.me admin yang benar; invalid disembunyikan.
17. Kurs tidak diisi atau tidak terverifikasi; kalkulator tetap menyebut estimasi manual.
18. Pastikan kalkulator USD tidak pernah menambah saldo.

Jangan menjalankan pembayaran produksi tanpa persetujuan pemilik dan hasil uji sandbox.
