/* CALISTA theme enhancement. Never handles credentials, payment proof or balance updates. */
(() => {
  'use strict';
  const config = window.CALISTA_CONFIG || {};
  const year = document.getElementById('year');
  if (year) year.textContent = new Date().getFullYear();

  const wa = document.getElementById('wa-float');
  const rawPhone = String(config.whatsapp || '').replace(/[^0-9]/g, '');
  if (wa && /^62[0-9]{8,13}$/.test(rawPhone)) {
    wa.href = `https://wa.me/${rawPhone}?text=${encodeURIComponent('Halo CALISTA DIGITAL STORE, saya ingin bertanya.')}`;
    wa.hidden = false;
  } else if (wa) {
    wa.hidden = true;
  }

  const slides = Array.from(document.querySelectorAll('.hero-slide'));
  const dots = Array.from(document.querySelectorAll('.carousel-dots button'));
  let current = 0;
  const showSlide = (index) => {
    if (!slides.length) return;
    current = (index + slides.length) % slides.length;
    slides.forEach((slide, i) => {
      slide.classList.toggle('is-active', i === current);
      slide.setAttribute('aria-hidden', i === current ? 'false' : 'true');
    });
    dots.forEach((dot, i) => dot.setAttribute('aria-current', i === current ? 'true' : 'false'));
  };
  document.querySelector('[data-carousel-prev]')?.addEventListener('click', () => showSlide(current - 1));
  document.querySelector('[data-carousel-next]')?.addEventListener('click', () => showSlide(current + 1));
  dots.forEach((dot, i) => dot.addEventListener('click', () => showSlide(i)));
  if (slides.length > 1) {
    showSlide(0);
    let timer = window.setInterval(() => showSlide(current + 1), 6500);
    const carousel = document.querySelector('.hero-carousel');
    carousel?.addEventListener('mouseenter', () => window.clearInterval(timer), { once: true });
  }

  const usdForm = document.getElementById('usd-form');
  usdForm?.addEventListener('submit', (event) => {
    event.preventDefault();
    const usd = Number(document.getElementById('usd-amount')?.value);
    const rate = Number(document.getElementById('usd-rate')?.value);
    const fee = Number(document.getElementById('usd-fee')?.value || 0);
    const result = document.getElementById('usd-result');
    if (!result) return;
    if (!Number.isFinite(usd) || !Number.isFinite(rate) || !Number.isFinite(fee) || usd <= 0 || rate <= 0 || fee < 0) {
      result.textContent = 'Masukkan angka USD, kurs, dan biaya yang valid.';
      return;
    }
    const gross = usd * rate;
    const net = Math.max(0, gross - fee);
    const format = (value) => new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(value);
    result.innerHTML = `Estimasi sebelum biaya: <strong>${format(gross)}</strong><div>Biaya: ${format(fee)}</div><div>Estimasi bersih: <b>${format(net)}</b></div><small>Perhitungan saja — bukan penukaran dana atau penambahan saldo.</small>`;
  });
})();
