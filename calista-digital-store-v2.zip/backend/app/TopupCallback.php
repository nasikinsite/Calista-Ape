<?php
declare(strict_types=1);
namespace Calista;
use Calista\Http\Response;
use PDO;
final class TopupCallback {
    public function handle(): never {
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') Response::json(['error' => 'Method not allowed'], 405);
        $secret = env_value('BUKAOLSHOP_CALLBACK_SECRET');
        if (!$secret) Response::json(['error' => 'Callback belum dikonfigurasi.'], 503);
        $received = (string)($_POST['secret_callback'] ?? '');
        if ($received === '' || !hash_equals($secret, $received)) {
            error_log('CALISTA: callback rejected (invalid secret)');
            Response::json(['error' => 'Callback tidak valid.'], 401);
        }
        $status = (string)($_POST['status'] ?? '');
        if ($status === 'topup_dibatalkan') $this->cancel();
        if ($status !== 'ok') Response::json(['error' => 'Status callback tidak dikenal.'], 422);

        $required = ['id_user','token_topup','jumlah_topup','kode_unik','total_topup'];
        foreach ($required as $key) {
            if (!isset($_POST[$key]) || trim((string)$_POST[$key]) === '') Response::json(['error' => 'Data callback tidak lengkap.'], 422);
        }
        $userId = trim((string)$_POST['id_user']);
        $token = trim((string)$_POST['token_topup']);
        $amount = filter_var($_POST['jumlah_topup'], FILTER_VALIDATE_INT);
        $unique = filter_var($_POST['kode_unik'], FILTER_VALIDATE_INT);
        $total = filter_var($_POST['total_topup'], FILTER_VALIDATE_INT);
        if ($amount === false || $amount < 1 || $unique === false || $unique < 0 || $total === false || $total !== $amount + $unique || strlen($token) > 190 || strlen($userId) > 190) {
            Response::json(['error' => 'Data nominal tidak valid.'], 422);
        }
        try {
            $pdo = db();
            $pdo->beginTransaction();
            $find = $pdo->prepare('SELECT id_user, amount, unique_code, total_amount, status FROM topup_requests WHERE token_topup=:token FOR UPDATE');
            $find->execute(['token' => $token]);
            $existing = $find->fetch(PDO::FETCH_ASSOC);
            if ($existing) {
                $same = hash_equals((string)$existing['id_user'], $userId)
                    && (int)$existing['amount'] === $amount
                    && (int)$existing['unique_code'] === $unique
                    && (int)$existing['total_amount'] === $total;
                if (!$same) {
                    $pdo->rollBack();
                    Response::json(['error' => 'Token topup sudah terdaftar dengan data berbeda.'], 409);
                }
                $pdo->commit();
                Response::json(['status' => 'received', 'duplicate' => true, 'message' => 'Permintaan sudah tercatat. Pembayaran dan konfirmasi saldo belum diaktifkan.'], 202);
            }
            $insert = $pdo->prepare("INSERT INTO topup_requests (id_user, token_topup, amount, unique_code, total_amount, status) VALUES (:uid,:token,:amount,:unique_code,:total,'awaiting_payment')");
            $insert->execute(['uid' => $userId, 'token' => $token, 'amount' => $amount, 'unique_code' => $unique, 'total' => $total]);
            $pdo->commit();
        } catch (\Throwable $e) {
            if (isset($pdo) && $pdo instanceof PDO && $pdo->inTransaction()) $pdo->rollBack();
            error_log('CALISTA: failed to store topup callback');
            Response::json(['error' => 'Permintaan belum dapat disimpan.'], 500);
        }
        // No invoice or balance is created here. Owner must implement and test a verified
        // payment provider adapter and the exact official BukaOlshop confirmation API.
        Response::json(['status' => 'received', 'message' => 'Permintaan tercatat. Pembayaran belum diaktifkan; saldo belum ditambahkan.'], 202);
    }

    private function cancel(): never {
        $token = trim((string)($_POST['token_topup'] ?? ''));
        if ($token === '' || strlen($token) > 190) Response::json(['error' => 'Token topup tidak valid.'], 422);
        try {
            $stmt = db()->prepare("UPDATE topup_requests SET status='cancelled', updated_at=NOW() WHERE token_topup=:token AND status IN ('awaiting_payment','pending')");
            $stmt->execute(['token' => $token]);
        } catch (\Throwable $e) {
            error_log('CALISTA: failed to persist cancellation callback');
            Response::json(['error' => 'Callback diterima tetapi gagal dicatat.'], 500);
        }
        Response::json(['status' => 'cancelled', 'updated' => $stmt->rowCount() > 0]);
    }
}
