# CALISTA DIGITAL STORE

Source project for a premium Indonesian digital-storefront theme designed to be installed as a custom BukaOlshop website theme, plus an optional PHP 8.x / MySQL backend foundation.

> **Important:** This is a development package, not a live store. No merchant credentials, domain, hosting, payment gateway, provider SKU mapping, or production BukaOlshop account is included. Never claim a real payment or balance credit until the official integration has been configured and end-to-end tested.

## Project status

| Component | Status |
|---|---|
| Premium storefront theme | Implemented in source |
| Responsive mobile navigation | Implemented |
| Home hero and accessible banner carousel | Implemented (static editable content) |
| Category entry page | Implemented; product list remains native BukaOlshop |
| Login, registration, cart, account, native TopUp links | Links prepared; verify paths on owner's store build |
| Product detail and checkout | Intentionally left to native BukaOlshop renderer |
| USD/IDR calculator | Implemented; manual rate, estimate only |
| WhatsApp floating link | Implemented; hidden until owner configures a valid Indonesian number |
| Help, terms, privacy, refund, TopUp information | Template pages implemented; owner must review legal/business details |
| PHP backend health endpoint | Implemented |
| USD estimate API | Implemented; arithmetic only, no balance update |
| Override TopUp callback | Secret validation, field validation, duplicate-token consistency, cancellation record |
| Gateway invoice / signed payment webhook | Not implemented; provider and credentials required |
| BukaOlshop balance confirmation API | Not implemented; exact current API contract and credentials must be verified first |
| Product/catalog API sync | Not implemented; product renderer and catalog remain native |
| Admin dashboard | Not implemented; database schema foundation only |

## 1. Official platform references

- Theme repository: https://github.com/bukaolshop/kostum-website-bukaolshop
- Override TopUp guide: https://help.bukaolshop.com/dokumentasi-fitur-override-topup-saldo/
- Open API documentation: https://bukaolshop.com/api-dokumentasi/
- Checkout customization guide: https://help.bukaolshop.com/dokumentasi-fitur-kostum-halaman-checkout/
- Native theme installation instructions are in the official repository README. Map each source file to the matching production theme section; do not paste the entire project into one HTML field.

The official theme repository contains distinct sections such as header, home, footer, CSS, JavaScript, account, categories, pages, payment and transactions. Confirm the exact section names offered by the owner's current Developer BukaOlshop editor before installation.

## 2. Install the storefront theme

1. Download and extract this ZIP.
2. Sign in to Developer BukaOlshop for the owner's store.
3. Open the theme list, create/select a theme, then create a production version.
4. Copy `theme/header.html` into the header section, `theme/home.html` into home, `theme/footer.html` into footer, and `theme/css.css` / `theme/script.js` into their matching CSS and JavaScript sections if offered.
5. For additional page files under `theme/pages/`, create matching custom page sections only if the editor supports them. If it does not, host the page content separately or keep the native pages. Do not assume a query string automatically maps to a custom file.
6. Preserve the native product list, detail, checkout, payment and transaction renderer. The custom category page is an entry/shortcut page only; it does not replace native product rendering.
7. Preview on mobile and desktop. Verify all native paths in the owner's store before publishing.

The project uses familiar native routes such as `/kategori`, `/search`, `/akun/login`, `/akun/daftar`, `/akun/?page=profil`, `/akun/?page=cart`, and `/akun/?page=topup`. Route availability and exact behavior must be confirmed against the actual store/build.

## 3. Theme configuration

Add this snippet in the footer before `script.js` and replace the placeholder with the owner's official WhatsApp number in international format without `+`:

```html
<script>
window.CALISTA_CONFIG = { whatsapp: '62xxxxxxxxxxx' };
</script>
```

Only the public WhatsApp number belongs here. Never place API tokens, callback secrets, passwords, or gateway secrets in theme HTML/JavaScript. The WhatsApp floating button remains hidden when the number is not valid.

The USD calculator accepts a manually entered rate and fee. It does not claim to be a live exchange-rate quote and does not create or transfer funds.

## 4. Optional PHP backend

Requirements:
- PHP 8.1+ recommended, PDO MySQL extension.
- MySQL 8 or compatible MariaDB with InnoDB.
- HTTPS.
- Web document root must point to `backend/public`, not the project root.

Install:

1. Create an empty database and a restricted database user.
2. Run `backend/database/migrations/001_initial.sql`.
3. Configure environment variables in the hosting control panel or server environment. Do not upload a publicly readable `.env` file.
4. Copy values from `.env.example` as a checklist; replace all placeholders with owner-controlled values.
5. Ensure `backend/app`, `backend/database`, and environment configuration are outside the public document root.
6. Visit `/health`; expected mode is `integration_not_configured` until integrations are completed.

The PHP bootstrap reads environment variables supplied by the hosting environment. It does not parse `.env` automatically.

## 5. Override TopUp integration boundary

The official Override TopUp guide documents POST fields:

- `status`
- `id_user`
- `token_topup`
- `jumlah_topup`
- `kode_unik`
- `total_topup`
- `secret_callback`

For cancellation, the documented status is `topup_dibatalkan` with `token_topup` and `secret_callback`.

The callback code in this package:
- checks the callback secret server-side using `hash_equals`;
- validates required fields and nominal arithmetic;
- records each token once;
- rejects reuse of a token with conflicting data;
- records eligible cancellation callbacks;
- never credits a balance.

**No payment invoice is generated and no balance is credited.** Before enabling a real flow, the owner must:

1. Review the latest official `POST konfirmasi-topup-member` endpoint specification in the BukaOlshop API documentation and confirm exact URL, authentication, request fields, response schema, and error handling.
2. Choose an approved payment provider and configure its official API credentials on the server.
3. Implement a gateway adapter with signature verification, amount/currency/reference checks, expiry handling, and webhook idempotency.
4. Implement the BukaOlshop confirmation adapter from the exact current official specification. Do not guess endpoint or parameter names.
5. Record safe integration outcomes and reconcile provider invoice, BukaOlshop token and member ID.
6. Test wrong signature, wrong amount, replay, duplicate webhook, cancellation, expiry, late payment, timeout and invalid token in sandbox before enabling production.
7. Obtain owner approval before any real payment test.

The current callback endpoint only stores a request and returns an explicit message that payment and balance credit are not activated. It must not be advertised as a working payment service.

## 6. API endpoints

### `GET /health`
Returns backend status. Does not expose secrets or database credentials.

### `POST /api/usd-estimate`
JSON body example:

```json
{"usd":10,"rate":16000,"fee":2500}
```

Returns gross and net arithmetic estimates. The rate is user-supplied and unverified. This endpoint does not update any account or balance.

### `POST /callbacks/bukaolshop/topup`
Receives documented Override TopUp callback fields. Requires `BUKAOLSHOP_CALLBACK_SECRET` to be configured in the server environment. It stores a pending request only; it does not create a payment invoice or call the balance confirmation API.

## 7. Tests

Run from project root:

```bash
php backend/tests/smoke.php
php -l backend/public/index.php
php -l backend/app/bootstrap.php
php -l backend/app/TopupCallback.php
```

See `docs/acceptance-test-plan.md` for integration and release tests. PHP syntax checks and static smoke checks do not prove compatibility with a live BukaOlshop account or payment provider.

## 8. Deployment and launch checklist

1. Compare PHP/database/backup/HTTPS requirements before purchasing hosting.
2. Buy domain/hosting only after owner approval; no purchases are made by this project.
3. Point DNS to hosting and enable HTTPS.
4. Deploy the backend with `backend/public` as the document root if using the backend.
5. Install the theme through Developer BukaOlshop and verify every section and native route.
6. Configure real product categories and map products/provider SKUs in the BukaOlshop dashboard.
7. Configure official provider(s) and test product delivery using the provider's permitted test process.
8. Configure payment gateway and callbacks only after credentials and exact API contracts are confirmed.
9. Complete sandbox tests. Only conduct a low-value production test with explicit owner approval.
10. Review terms, privacy, refund policy, business contact and customer support hours.
11. Configure daily backups and perform a restore test.
12. Publish only after native checkout, transaction status, payment callbacks, security and customer support have passed acceptance tests.

## 9. Security notes

- No API secret is present in frontend files.
- Do not expose project root, database migrations, logs, or app source via the web server.
- Use HTTPS and least-privilege database credentials.
- Keep production debug output disabled.
- Rotate callback and gateway secrets if exposed.
- The admin tables are only a schema foundation. Do not expose admin routes until authentication, secure sessions, CSRF protection, rate limiting, role checks and audit logging are implemented.
- Never treat a browser redirect, screenshot or user-submitted claim as payment verification.
