<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/bootstrap.php';
use Calista\Http\Response;

header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('X-Frame-Options: DENY');
header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
header('Cache-Control: no-store');
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
    header('Allow: GET, POST, OPTIONS');
    http_response_code(204);
    exit;
}
$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if ($path === '/health' && $method === 'GET') {
    Response::json(['app' => 'CALISTA backend', 'status' => 'ok', 'mode' => 'integration_not_configured']);
}
if ($path === '/api/usd-estimate' && $method === 'POST') {
    $length = (int)($_SERVER['CONTENT_LENGTH'] ?? 0);
    if ($length > 4096) Response::json(['error' => 'Request terlalu besar.'], 413);
    $body = json_decode(file_get_contents('php://input') ?: '', true);
    if (!is_array($body)) Response::json(['error' => 'Format JSON tidak valid.'], 400);
    $usd = filter_var($body['usd'] ?? null, FILTER_VALIDATE_FLOAT);
    $rate = filter_var($body['rate'] ?? null, FILTER_VALIDATE_FLOAT);
    $fee = filter_var($body['fee'] ?? 0, FILTER_VALIDATE_FLOAT);
    if ($usd === false || $rate === false || $fee === false || $usd <= 0 || $rate <= 0 || $fee < 0 || $usd > 100000 || $rate > 10000000 || $fee > 1000000000) {
        Response::json(['error' => 'Jumlah USD, kurs, atau biaya tidak valid.'], 422);
    }
    $gross = round($usd * $rate, 2);
    Response::json(['usd' => $usd, 'rate_idr' => $rate, 'fee_idr' => $fee, 'gross_idr' => $gross, 'net_estimate_idr' => max(0, $gross - $fee), 'note' => 'Estimasi saja. Kurs dimasukkan pengguna. Tidak menambah saldo.']);
}
if ($path === '/callbacks/bukaolshop/topup' && $method === 'POST') {
    $length = (int)($_SERVER['CONTENT_LENGTH'] ?? 0);
    if ($length > 16384) Response::json(['error' => 'Request terlalu besar.'], 413);
    require_once __DIR__ . '/../app/TopupCallback.php';
    (new Calista\TopupCallback())->handle();
}
header('Allow: GET, POST, OPTIONS');
Response::json(['error' => 'Not found'], 404);
